import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPassword = await bcrypt.hash("admin123", 10);
  const userPassword = await bcrypt.hash("user123", 10);

  await prisma.user.upsert({
    where: { email: "admin@marketplace.com" },
    update: {},
    create: {
      name: "Administrador",
      email: "admin@marketplace.com",
      password: adminPassword,
      role: "ADMIN",
    },
  });

  await prisma.user.upsert({
    where: { email: "user@marketplace.com" },
    update: {},
    create: {
      name: "Cliente Teste",
      email: "user@marketplace.com",
      password: userPassword,
      role: "USER",
    },
  });

  const categories = [
    { name: "Eletrônicos", slug: "eletronicos" },
    { name: "Casa e Decoração", slug: "casa-e-decoracao" },
    { name: "Moda", slug: "moda" },
    { name: "Livros", slug: "livros" },
  ];

  for (const c of categories) {
    await prisma.category.upsert({ where: { slug: c.slug }, update: {}, create: c });
  }

  const eletronicos = await prisma.category.findUniqueOrThrow({ where: { slug: "eletronicos" } });
  const casa = await prisma.category.findUniqueOrThrow({ where: { slug: "casa-e-decoracao" } });
  const moda = await prisma.category.findUniqueOrThrow({ where: { slug: "moda" } });
  const livros = await prisma.category.findUniqueOrThrow({ where: { slug: "livros" } });

  const products = [
    {
      name: "Fone de Ouvido Bluetooth",
      description: "Fone sem fio com cancelamento de ruído e 30h de bateria.",
      price: 249.9,
      stock: 40,
      categoryId: eletronicos.id,
      imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600",
    },
    {
      name: "Teclado Mecânico Compacto",
      description: "Teclado 60% com switches hot-swap e RGB.",
      price: 389.0,
      stock: 25,
      categoryId: eletronicos.id,
      imageUrl: "https://images.unsplash.com/photo-1595225476474-63038da0f2d3?w=600",
    },
    {
      name: "Luminária de Mesa Articulada",
      description: "Luminária LED com três temperaturas de luz.",
      price: 129.5,
      stock: 60,
      categoryId: casa.id,
      imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600",
    },
    {
      name: "Vaso de Cerâmica Artesanal",
      description: "Peça única em cerâmica, feita à mão.",
      price: 89.9,
      stock: 15,
      categoryId: casa.id,
      imageUrl: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=600",
    },
    {
      name: "Camiseta Algodão Orgânico",
      description: "Camiseta unissex, tecido 100% algodão orgânico.",
      price: 79.0,
      stock: 100,
      categoryId: moda.id,
      imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600",
    },
    {
      name: "Jaqueta Corta-Vento",
      description: "Impermeável, leve e dobrável.",
      price: 219.0,
      stock: 30,
      categoryId: moda.id,
      imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600",
    },
    {
      name: "Clean Code",
      description: "Robert C. Martin — boas práticas de desenvolvimento de software.",
      price: 99.0,
      stock: 50,
      categoryId: livros.id,
      imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600",
    },
    {
      name: "O Programador Pragmático",
      description: "Guia clássico para o desenvolvimento de software eficaz.",
      price: 89.0,
      stock: 45,
      categoryId: livros.id,
      imageUrl: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600",
    },
  ];

  for (const p of products) {
    const exists = await prisma.product.findFirst({ where: { name: p.name } });
    if (!exists) await prisma.product.create({ data: p });
  }

  console.log("Seed concluído.");
  console.log("Login admin: admin@marketplace.com / admin123");
  console.log("Login usuário: user@marketplace.com / user123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
