import { Router } from "express";
import { z } from "zod";
import { prisma } from "../utils/prisma";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();

// GET /api/products?search=&categoryId=&page=&pageSize=
router.get("/", async (req, res) => {
  const { search, categoryId } = req.query as { search?: string; categoryId?: string };
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(50, Number(req.query.pageSize) || 12);

  const where = {
    ...(search
      ? { name: { contains: search, mode: "insensitive" as const } }
      : {}),
    ...(categoryId ? { categoryId } : {}),
  };

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: { category: true },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.product.count({ where }),
  ]);

  res.json({ products, total, page, pageSize, totalPages: Math.ceil(total / pageSize) });
});

router.get("/:id", async (req, res) => {
  const product = await prisma.product.findUnique({
    where: { id: req.params.id },
    include: { category: true },
  });
  if (!product) return res.status(404).json({ error: "Produto não encontrado." });
  res.json(product);
});

const productSchema = z.object({
  name: z.string().min(2),
  description: z.string().min(5),
  price: z.number().positive(),
  stock: z.number().int().min(0),
  categoryId: z.string().min(1),
  imageUrl: z.string().url().optional().or(z.literal("")),
});

router.post("/", authenticate, authorize("ADMIN"), async (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0].message });
  }
  const product = await prisma.product.create({ data: parsed.data });
  res.status(201).json(product);
});

router.put("/:id", authenticate, authorize("ADMIN"), async (req, res) => {
  const parsed = productSchema.partial().safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0].message });
  }
  const product = await prisma.product
    .update({ where: { id: req.params.id }, data: parsed.data })
    .catch(() => null);
  if (!product) return res.status(404).json({ error: "Produto não encontrado." });
  res.json(product);
});

router.delete("/:id", authenticate, authorize("ADMIN"), async (req, res) => {
  await prisma.product.delete({ where: { id: req.params.id } }).catch(() => null);
  res.status(204).send();
});

export default router;
