import { Router } from "express";
import { z } from "zod";
import { prisma } from "../utils/prisma";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();

router.get("/", async (_req, res) => {
  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { products: true } } },
  });
  res.json(categories);
});

const categorySchema = z.object({
  name: z.string().min(2),
});

function slugify(name: string) {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

router.post("/", authenticate, authorize("ADMIN"), async (req, res) => {
  const parsed = categorySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Nome da categoria é obrigatório." });

  const { name } = parsed.data;
  const category = await prisma.category.create({
    data: { name, slug: slugify(name) },
  });
  res.status(201).json(category);
});

router.delete("/:id", authenticate, authorize("ADMIN"), async (req, res) => {
  await prisma.category.delete({ where: { id: req.params.id } }).catch(() => null);
  res.status(204).send();
});

export default router;
