import { Router } from "express";
import { z } from "zod";
import { randomUUID } from "crypto";
import { prisma } from "../utils/prisma";
import { authenticate, authorize } from "../middleware/auth";

const router = Router();

const checkoutSchema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string(),
        quantity: z.number().int().positive(),
      })
    )
    .min(1, "O carrinho está vazio."),
  // Dados de "cartão" puramente simulados — nunca são armazenados nem validados de verdade.
  card: z.object({
    number: z.string().min(12),
    expiry: z.string(),
    cvc: z.string(),
  }),
});

/**
 * Simula a chamada assíncrona a um gateway de pagamento externo
 * (ex.: Stripe em modo teste). Números de cartão terminados em "0000"
 * simulam uma recusa, para demonstrar o fluxo de erro.
 */
function simulatePaymentGateway(cardNumber: string): Promise<{ success: boolean; transactionId: string }> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const declined = cardNumber.replace(/\s/g, "").endsWith("0000");
      resolve({ success: !declined, transactionId: `sim_${randomUUID()}` });
    }, 600); // latência artificial, como uma chamada de rede real
  });
}

// POST /api/orders/checkout — cria o pedido, "cobra" o pagamento simulado e baixa o estoque.
router.post("/checkout", authenticate, async (req, res) => {
  const parsed = checkoutSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0].message });
  }
  const { items, card } = parsed.data;

  try {
    const order = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: items.map((i) => i.productId) } },
      });

      let total = 0;
      const orderItemsData = items.map((item) => {
        const product = products.find((p) => p.id === item.productId);
        if (!product) throw new Error(`Produto ${item.productId} não encontrado.`);
        if (product.stock < item.quantity) {
          throw new Error(`Estoque insuficiente para "${product.name}".`);
        }
        total += product.price * item.quantity;
        return { productId: product.id, quantity: item.quantity, price: product.price };
      });

      const createdOrder = await tx.order.create({
        data: {
          userId: req.user!.userId,
          total,
          status: "PENDING",
          items: { create: orderItemsData },
        },
        include: { items: { include: { product: true } } },
      });

      // Reserva o estoque otimisticamente; será revertido se o pagamento falhar.
      for (const item of items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity } },
        });
      }

      return createdOrder;
    });

    // Chamada ao gateway simulado (fora da transação de banco, como numa API real).
    const paymentResult = await simulatePaymentGateway(card.number);

    if (paymentResult.success) {
      const [, payment] = await prisma.$transaction([
        prisma.order.update({ where: { id: order.id }, data: { status: "PAID" } }),
        prisma.payment.create({
          data: {
            orderId: order.id,
            status: "succeeded",
            transactionId: paymentResult.transactionId,
          },
        }),
      ]);
      return res.status(201).json({ order: { ...order, status: "PAID" }, payment });
    }

    // Pagamento recusado: repõe o estoque e marca o pedido como falho.
    await prisma.$transaction(async (tx) => {
      for (const item of items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { increment: item.quantity } },
        });
      }
      await tx.order.update({ where: { id: order.id }, data: { status: "FAILED" } });
      await tx.payment.create({
        data: {
          orderId: order.id,
          status: "failed",
          transactionId: paymentResult.transactionId,
        },
      });
    });

    return res.status(402).json({ error: "Pagamento recusado pelo gateway simulado." });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Erro ao processar o pedido.";
    return res.status(400).json({ error: message });
  }
});

// GET /api/orders — pedidos do usuário autenticado.
router.get("/", authenticate, async (req, res) => {
  const orders = await prisma.order.findMany({
    where: { userId: req.user!.userId },
    include: { items: { include: { product: true } }, payment: true },
    orderBy: { createdAt: "desc" },
  });
  res.json(orders);
});

// GET /api/orders/all — visão de administrador com todos os pedidos.
router.get("/all", authenticate, authorize("ADMIN"), async (_req, res) => {
  const orders = await prisma.order.findMany({
    include: { items: { include: { product: true } }, payment: true, user: true },
    orderBy: { createdAt: "desc" },
  });
  res.json(orders);
});

export default router;
