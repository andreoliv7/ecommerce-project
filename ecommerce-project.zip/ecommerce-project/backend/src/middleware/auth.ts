import { Request, Response, NextFunction } from "express";
import { verifyToken, JwtPayload } from "../utils/jwt";

// Estende o Request do Express para carregar o usuário autenticado.
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

/** Exige um JWT válido no header Authorization: Bearer <token>. */
export function authenticate(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Token de autenticação ausente." });
  }

  const token = header.slice("Bearer ".length);

  try {
    req.user = verifyToken(token);
    next();
  } catch {
    return res.status(401).json({ error: "Token inválido ou expirado." });
  }
}

/** Controle de acesso por papel (RBAC). Use após `authenticate`. */
export function authorize(...roles: Array<"USER" | "ADMIN">) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: "Não autenticado." });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Permissão insuficiente para esta ação." });
    }
    next();
  };
}

/** Middleware opcional: anexa o usuário se houver token, mas não bloqueia. */
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (header?.startsWith("Bearer ")) {
    try {
      req.user = verifyToken(header.slice("Bearer ".length));
    } catch {
      /* ignora token inválido em rota opcional */
    }
  }
  next();
}
