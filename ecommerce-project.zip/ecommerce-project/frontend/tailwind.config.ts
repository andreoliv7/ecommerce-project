import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#132420",      // verde-ferrugem escuro, cor de base (headers, texto forte)
        forest: "#1F4A3C",   // verde principal da marca
        sand: "#EFE9DA",     // fundo claro, quente sem ser o "cream cliché"
        paper: "#FAF8F2",    // fundo de cartões
        gold: "#D6A445",     // acento principal (preço, CTAs)
        rust: "#B5502E",     // acento secundário, usado com moderação (erros/destaques)
        line: "#D8CFB8",     // linhas/divisores
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      backgroundImage: {
        "grain": "radial-gradient(circle at 1px 1px, rgba(19,36,32,0.06) 1px, transparent 0)",
      },
    },
  },
  plugins: [],
};
export default config;
