"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Order } from "@/lib/types";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

const statusLabel: Record<string, string> = {
  PENDING: "Pendente",
  PAID: "Pago",
  FAILED: "Falhou",
  SHIPPED: "Enviado",
  CANCELLED: "Cancelado",
};

const statusColor: Record<string, string> = {
  PENDING: "bg-gold/20 text-gold",
  PAID: "bg-forest/15 text-forest",
  FAILED: "bg-rust/15 text-rust",
  SHIPPED: "bg-forest/15 text-forest",
  CANCELLED: "bg-ink/10 text-ink/60",
};

export default function OrdersPage() {
  const { user, token, loading: authLoading } = useAuth();
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) router.push("/login");
  }, [authLoading, user, router]);

  useEffect(() => {
    if (!token) return;
    apiFetch<Order[]>("/api/orders", { token })
      .then(setOrders)
      .finally(() => setLoading(false));
  }, [token]);

  if (authLoading || loading) return <p className="text-ink/50">Carregando pedidos…</p>;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl text-ink">Meus pedidos</h1>

      {orders.length === 0 ? (
        <p className="text-ink/60">Você ainda não fez nenhum pedido.</p>
      ) : (
        orders.map((order) => (
          <div key={order.id} className="rounded-lg border border-line bg-paper p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs text-ink/50">Pedido #{order.id.slice(0, 8)}</p>
                <p className="text-sm text-ink/60">
                  {new Date(order.createdAt).toLocaleString("pt-BR")}
                </p>
              </div>
              <span className={`rounded-full px-3 py-1 text-xs font-medium ${statusColor[order.status]}`}>
                {statusLabel[order.status]}
              </span>
            </div>

            <ul className="mt-4 space-y-1 text-sm text-ink/80">
              {order.items.map((item) => (
                <li key={item.id} className="flex justify-between">
                  <span>
                    {item.quantity}× {item.product.name}
                  </span>
                  <span>{formatBRL(item.price * item.quantity)}</span>
                </li>
              ))}
            </ul>

            <div className="mt-3 flex justify-between border-t border-line pt-3 font-display text-ink">
              <span>Total</span>
              <span className="text-gold">{formatBRL(order.total)}</span>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
