"use client";

import { useEffect, useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { apiFetch, ApiError } from "@/lib/api";
import { Product, Category } from "@/lib/types";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

const emptyForm = { name: "", description: "", price: "", stock: "", categoryId: "", imageUrl: "" };

export default function AdminPage() {
  const { user, token, loading: authLoading } = useAuth();
  const router = useRouter();

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [newCategory, setNewCategory] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!authLoading && user?.role !== "ADMIN") router.push("/");
  }, [authLoading, user, router]);

  async function refresh() {
    const [prodData, catData] = await Promise.all([
      apiFetch<{ products: Product[] }>("/api/products?pageSize=50"),
      apiFetch<Category[]>("/api/categories"),
    ]);
    setProducts(prodData.products);
    setCategories(catData);
  }

  useEffect(() => {
    if (user?.role === "ADMIN") refresh();
  }, [user]);

  if (authLoading || user?.role !== "ADMIN") return null;

  async function handleCreateCategory(e: FormEvent) {
    e.preventDefault();
    if (!newCategory.trim()) return;
    await apiFetch("/api/categories", {
      method: "POST",
      token,
      body: JSON.stringify({ name: newCategory }),
    });
    setNewCategory("");
    refresh();
  }

  async function handleSubmitProduct(e: FormEvent) {
    e.preventDefault();
    setError("");
    const payload = {
      name: form.name,
      description: form.description,
      price: Number(form.price),
      stock: Number(form.stock),
      categoryId: form.categoryId,
      imageUrl: form.imageUrl || undefined,
    };
    try {
      if (editingId) {
        await apiFetch(`/api/products/${editingId}`, {
          method: "PUT",
          token,
          body: JSON.stringify(payload),
        });
      } else {
        await apiFetch("/api/products", { method: "POST", token, body: JSON.stringify(payload) });
      }
      setForm(emptyForm);
      setEditingId(null);
      refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Erro ao salvar produto.");
    }
  }

  function startEdit(p: Product) {
    setEditingId(p.id);
    setForm({
      name: p.name,
      description: p.description,
      price: String(p.price),
      stock: String(p.stock),
      categoryId: p.categoryId,
      imageUrl: p.imageUrl || "",
    });
  }

  async function handleDelete(id: string) {
    if (!confirm("Remover este produto?")) return;
    await apiFetch(`/api/products/${id}`, { method: "DELETE", token });
    refresh();
  }

  return (
    <div className="space-y-10">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl text-ink">Painel administrativo</h1>
        <Link href="/admin/orders" className="text-forest underline">
          Ver todos os pedidos →
        </Link>
      </div>

      <section className="rounded-lg border border-line bg-paper p-6">
        <h2 className="font-display text-xl text-ink">Categorias</h2>
        <form onSubmit={handleCreateCategory} className="mt-3 flex gap-2">
          <input
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            placeholder="Nova categoria"
            className="focus-ring flex-1 rounded-md border border-line bg-white px-3 py-2"
          />
          <button className="focus-ring rounded-full bg-forest px-4 py-2 text-paper hover:bg-ink">
            Adicionar
          </button>
        </form>
        <div className="mt-3 flex flex-wrap gap-2">
          {categories.map((c) => (
            <span key={c.id} className="rounded-full bg-sand px-3 py-1 text-sm">
              {c.name} ({c._count?.products ?? 0})
            </span>
          ))}
        </div>
      </section>

      <section className="rounded-lg border border-line bg-paper p-6">
        <h2 className="font-display text-xl text-ink">
          {editingId ? "Editar produto" : "Novo produto"}
        </h2>
        <form onSubmit={handleSubmitProduct} className="mt-3 grid gap-3 sm:grid-cols-2">
          <input
            required
            placeholder="Nome"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2"
          />
          <select
            required
            value={form.categoryId}
            onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2"
          >
            <option value="">Categoria…</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <input
            required
            type="number"
            step="0.01"
            placeholder="Preço"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2"
          />
          <input
            required
            type="number"
            placeholder="Estoque"
            value={form.stock}
            onChange={(e) => setForm({ ...form, stock: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2"
          />
          <input
            placeholder="URL da imagem (opcional)"
            value={form.imageUrl}
            onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2 sm:col-span-2"
          />
          <textarea
            required
            placeholder="Descrição"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="focus-ring rounded-md border border-line bg-white px-3 py-2 sm:col-span-2"
            rows={3}
          />

          {error && <p className="text-sm text-rust sm:col-span-2">{error}</p>}

          <div className="flex gap-2 sm:col-span-2">
            <button className="focus-ring rounded-full bg-forest px-6 py-2 text-paper hover:bg-ink">
              {editingId ? "Salvar alterações" : "Criar produto"}
            </button>
            {editingId && (
              <button
                type="button"
                onClick={() => {
                  setEditingId(null);
                  setForm(emptyForm);
                }}
                className="rounded-full border border-line px-6 py-2"
              >
                Cancelar
              </button>
            )}
          </div>
        </form>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-xl text-ink">Produtos cadastrados</h2>
        <div className="overflow-x-auto rounded-lg border border-line bg-paper">
          <table className="w-full text-left text-sm">
            <thead className="bg-sand text-ink/60">
              <tr>
                <th className="px-4 py-2">Nome</th>
                <th className="px-4 py-2">Categoria</th>
                <th className="px-4 py-2">Preço</th>
                <th className="px-4 py-2">Estoque</th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="px-4 py-2">{p.name}</td>
                  <td className="px-4 py-2 text-ink/60">{p.category?.name}</td>
                  <td className="px-4 py-2">{formatBRL(p.price)}</td>
                  <td className="px-4 py-2">{p.stock}</td>
                  <td className="space-x-3 px-4 py-2 text-right">
                    <button onClick={() => startEdit(p)} className="text-forest underline">
                      Editar
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="text-rust underline">
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
