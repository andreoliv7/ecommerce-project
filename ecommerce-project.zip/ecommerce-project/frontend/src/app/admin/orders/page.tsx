"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { apiFetch } from "@/lib/api";
import { Order } from "@/lib/types";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

export default function AdminOrdersPage() {
  const { user, token, loading: authLoading } = useAuth();
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!authLoading && user?.role !== "ADMIN") router.push("/");
  }, [authLoading, user, router]);

  useEffect(() => {
    if (user?.role === "ADMIN" && token) {
      apiFetch<Order[]>("/api/orders/all", { token }).then(setOrders);
    }
  }, [user, token]);

  if (authLoading || user?.role !== "ADMIN") return null;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl text-ink">Todos os pedidos</h1>
      <div className="overflow-x-auto rounded-lg border border-line bg-paper">
        <table className="w-full text-left text-sm">
          <thead className="bg-sand text-ink/60">
            <tr>
              <th className="px-4 py-2">Cliente</th>
              <th className="px-4 py-2">Itens</th>
              <th className="px-4 py-2">Total</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2">Data</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-t border-line align-top">
                <td className="px-4 py-2">
                  <p>{order.user?.name}</p>
                  <p className="text-xs text-ink/50">{order.user?.email}</p>
                </td>
                <td className="px-4 py-2 text-ink/70">
                  {order.items.map((i) => `${i.quantity}× ${i.product.name}`).join(", ")}
                </td>
                <td className="px-4 py-2">{formatBRL(order.total)}</td>
                <td className="px-4 py-2">{order.status}</td>
                <td className="px-4 py-2 text-ink/50">
                  {new Date(order.createdAt).toLocaleDateString("pt-BR")}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
