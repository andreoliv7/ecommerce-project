"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import { apiFetch, ApiError } from "@/lib/api";
import { Product } from "@/lib/types";
import { useCartStore } from "@/store/cartStore";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState("");
  const [added, setAdded] = useState(false);
  const addItem = useCartStore((s) => s.addItem);

  useEffect(() => {
    apiFetch<Product>(`/api/products/${id}`)
      .then(setProduct)
      .catch((e) => setError(e instanceof ApiError ? e.message : "Erro ao carregar produto."));
  }, [id]);

  if (error) return <p className="text-rust">{error}</p>;
  if (!product) return <p className="text-ink/50">Carregando…</p>;

  return (
    <div className="grid gap-10 sm:grid-cols-2">
      <div className="relative aspect-square overflow-hidden rounded-lg bg-sand">
        {product.imageUrl && (
          <Image src={product.imageUrl} alt={product.name} fill className="object-cover" />
        )}
      </div>

      <div className="space-y-5">
        <div>
          <p className="text-xs uppercase tracking-wide text-ink/50">{product.category?.name}</p>
          <h1 className="font-display text-3xl text-ink">{product.name}</h1>
        </div>

        <p className="font-display text-3xl text-gold">{formatBRL(product.price)}</p>
        <p className="leading-relaxed text-ink/80">{product.description}</p>

        <p className="text-sm text-ink/50">
          {product.stock > 0 ? `${product.stock} em estoque` : "Produto esgotado"}
        </p>

        {product.stock > 0 && (
          <div className="flex items-center gap-4">
            <div className="flex items-center rounded-full border border-line">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="focus-ring px-3 py-2"
                aria-label="Diminuir quantidade"
              >
                −
              </button>
              <span className="w-8 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                className="focus-ring px-3 py-2"
                aria-label="Aumentar quantidade"
              >
                +
              </button>
            </div>

            <button
              onClick={() => {
                addItem(product, quantity);
                setAdded(true);
                setTimeout(() => setAdded(false), 1500);
              }}
              className="focus-ring flex-1 rounded-full bg-forest px-6 py-2.5 text-paper transition-colors hover:bg-ink"
            >
              {added ? "Adicionado ✓" : "Adicionar ao carrinho"}
            </button>
          </div>
        )}

        <button onClick={() => router.push("/cart")} className="text-sm text-forest underline">
          Ir para o carrinho
        </button>
      </div>
    </div>
  );
}
