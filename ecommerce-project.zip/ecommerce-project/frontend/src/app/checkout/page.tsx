"use client";

import { useEffect, useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { useCartStore } from "@/store/cartStore";
import { useAuth } from "@/context/AuthContext";
import { apiFetch, ApiError } from "@/lib/api";
import { Order } from "@/lib/types";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

export default function CheckoutPage() {
  const { lines, total, clear } = useCartStore();
  const { user, token } = useAuth();
  const router = useRouter();

  const [mounted, setMounted] = useState(false);
  const [cardNumber, setCardNumber] = useState("4242 4242 4242 4242");
  const [expiry, setExpiry] = useState("12/29");
  const [cvc, setCvc] = useState("123");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (mounted && !user) router.push("/login");
    if (mounted && lines.length === 0) router.push("/cart");
  }, [mounted, user, lines.length, router]);

  if (!mounted || !user || lines.length === 0) return null;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const data = await apiFetch<{ order: Order }>("/api/orders/checkout", {
        method: "POST",
        token,
        body: JSON.stringify({
          items: lines.map((l) => ({ productId: l.product.id, quantity: l.quantity })),
          card: { number: cardNumber, expiry, cvc },
        }),
      });
      clear();
      router.push(`/orders?justPaid=${data.order.id}`);
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : "Não foi possível concluir o pagamento. Tente novamente."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-lg">
      <h1 className="font-display text-3xl text-ink">Finalizar compra</h1>
      <p className="mt-2 text-sm text-ink/60">
        Pagamento simulado — nenhum dado real é enviado. Use um cartão terminado em{" "}
        <code>0000</code> para testar uma recusa.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4 rounded-lg border border-line bg-paper p-6">
        <div>
          <label className="text-sm text-ink/70">Número do cartão</label>
          <input
            required
            value={cardNumber}
            onChange={(e) => setCardNumber(e.target.value)}
            className="focus-ring mt-1 w-full rounded-md border border-line bg-white px-4 py-2"
          />
        </div>
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="text-sm text-ink/70">Validade</label>
            <input
              required
              value={expiry}
              onChange={(e) => setExpiry(e.target.value)}
              className="focus-ring mt-1 w-full rounded-md border border-line bg-white px-4 py-2"
            />
          </div>
          <div className="flex-1">
            <label className="text-sm text-ink/70">CVC</label>
            <input
              required
              value={cvc}
              onChange={(e) => setCvc(e.target.value)}
              className="focus-ring mt-1 w-full rounded-md border border-line bg-white px-4 py-2"
            />
          </div>
        </div>

        <div className="flex justify-between border-t border-line pt-4 font-display text-lg">
          <span>Total</span>
          <span className="text-gold">{formatBRL(total())}</span>
        </div>

        {error && <p className="text-sm text-rust">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="focus-ring w-full rounded-full bg-forest px-6 py-2.5 text-paper hover:bg-ink disabled:opacity-60"
        >
          {loading ? "Processando pagamento…" : `Pagar ${formatBRL(total())}`}
        </button>
      </form>
    </div>
  );
}
