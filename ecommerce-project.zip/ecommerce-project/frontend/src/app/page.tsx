"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import { Product, Category } from "@/lib/types";
import ProductCard from "@/components/ProductCard";

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch<Category[]>("/api/categories").then(setCategories).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (categoryId) params.set("categoryId", categoryId);

    const timeout = setTimeout(() => {
      apiFetch<{ products: Product[] }>(`/api/products?${params.toString()}`)
        .then((data) => setProducts(data.products))
        .catch(() => setProducts([]))
        .finally(() => setLoading(false));
    }, 250); // debounce da busca

    return () => clearTimeout(timeout);
  }, [search, categoryId]);

  return (
    <div className="space-y-10">
      <section className="tag-card bg-forest px-10 py-14 text-paper">
        <span className="tag-hole" style={{ background: "#1F4A3C" }} aria-hidden />
        <p className="font-body text-sm uppercase tracking-[0.2em] text-gold">
          feira aberta, todos os dias
        </p>
        <h1 className="mt-3 max-w-xl font-display text-4xl leading-tight sm:text-5xl">
          Cada etiqueta conta a história de quem fez.
        </h1>
        <p className="mt-4 max-w-md text-paper/80">
          Eletrônicos, casa, moda e livros — de vendedores reais, com estoque e
          pagamento simulados de ponta a ponta.
        </p>
      </section>

      <section className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Buscar produtos…"
          className="focus-ring w-full rounded-full border border-line bg-paper px-5 py-2.5 sm:max-w-xs"
        />
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setCategoryId("")}
            className={`focus-ring rounded-full border px-4 py-1.5 text-sm transition-colors ${
              categoryId === "" ? "border-forest bg-forest text-paper" : "border-line bg-paper"
            }`}
          >
            Todas
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setCategoryId(c.id)}
              className={`focus-ring rounded-full border px-4 py-1.5 text-sm transition-colors ${
                categoryId === c.id ? "border-forest bg-forest text-paper" : "border-line bg-paper"
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </section>

      {loading ? (
        <p className="text-ink/50">Carregando produtos…</p>
      ) : products.length === 0 ? (
        <p className="text-ink/50">Nenhum produto encontrado para esses filtros.</p>
      ) : (
        <section className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </section>
      )}
    </div>
  );
}
