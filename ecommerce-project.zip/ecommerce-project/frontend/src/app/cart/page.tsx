"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useCartStore } from "@/store/cartStore";
import { useAuth } from "@/context/AuthContext";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

export default function CartPage() {
  const { lines, setQuantity, removeItem, total } = useCartStore();
  const { user } = useAuth();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  if (lines.length === 0) {
    return (
      <div className="text-center">
        <p className="text-ink/60">Seu carrinho está vazio.</p>
        <Link href="/" className="mt-4 inline-block text-forest underline">
          Voltar ao catálogo
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <h1 className="font-display text-3xl text-ink">Seu carrinho</h1>
        {lines.map(({ product, quantity }) => (
          <div key={product.id} className="flex gap-4 rounded-lg border border-line bg-paper p-4">
            <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md bg-sand">
              {product.imageUrl && (
                <Image src={product.imageUrl} alt={product.name} fill className="object-cover" />
              )}
            </div>
            <div className="flex flex-1 flex-col justify-between">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-display text-lg text-ink">{product.name}</p>
                  <p className="text-sm text-ink/50">{formatBRL(product.price)} / un.</p>
                </div>
                <button
                  onClick={() => removeItem(product.id)}
                  className="text-sm text-rust hover:underline"
                >
                  Remover
                </button>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center rounded-full border border-line">
                  <button
                    onClick={() => setQuantity(product.id, Math.max(1, quantity - 1))}
                    className="focus-ring px-3 py-1"
                  >
                    −
                  </button>
                  <span className="w-8 text-center text-sm">{quantity}</span>
                  <button
                    onClick={() => setQuantity(product.id, Math.min(product.stock, quantity + 1))}
                    className="focus-ring px-3 py-1"
                  >
                    +
                  </button>
                </div>
                <span className="ml-auto font-display text-ink">
                  {formatBRL(product.price * quantity)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <aside className="h-fit space-y-4 rounded-lg border border-line bg-paper p-6">
        <h2 className="font-display text-xl text-ink">Resumo</h2>
        <div className="flex justify-between text-ink/70">
          <span>Subtotal</span>
          <span>{formatBRL(total())}</span>
        </div>
        <div className="flex justify-between font-display text-lg text-ink">
          <span>Total</span>
          <span className="text-gold">{formatBRL(total())}</span>
        </div>
        <button
          onClick={() => router.push(user ? "/checkout" : "/login")}
          className="focus-ring w-full rounded-full bg-forest px-6 py-2.5 text-paper hover:bg-ink"
        >
          {user ? "Finalizar compra" : "Entrar para finalizar"}
        </button>
      </aside>
    </div>
  );
}
