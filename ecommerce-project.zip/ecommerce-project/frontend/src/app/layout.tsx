import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import Navbar from "@/components/Navbar";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["500", "600", "700"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Vero Mercado — Marketplace",
  description: "Um marketplace completo: catálogo, carrinho, checkout e painel administrativo.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${fraunces.variable} ${inter.variable}`}>
      <body className="min-h-screen font-body text-ink antialiased">
        <AuthProvider>
          <Navbar />
          <main className="mx-auto max-w-6xl px-6 py-10">{children}</main>
          <footer className="mt-16 border-t border-line py-8 text-center text-sm text-ink/50">
            Vero Mercado — projeto de demonstração (dados e pagamentos simulados).
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
