export type Role = "USER" | "ADMIN";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  _count?: { products: number };
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  imageUrl?: string | null;
  categoryId: string;
  category?: Category;
}

export interface OrderItem {
  id: string;
  quantity: number;
  price: number;
  product: Product;
}

export type OrderStatus = "PENDING" | "PAID" | "FAILED" | "SHIPPED" | "CANCELLED";

export interface Order {
  id: string;
  status: OrderStatus;
  total: number;
  createdAt: string;
  items: OrderItem[];
  payment?: { status: string; transactionId: string } | null;
  user?: { name: string; email: string };
}
