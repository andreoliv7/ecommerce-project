"use client";

import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { useCartStore } from "@/store/cartStore";
import { useEffect, useState } from "react";

export default function Navbar() {
  const { user, logout } = useAuth();
  const count = useCartStore((s) => s.count());
  const [mounted, setMounted] = useState(false);

  // Evita mismatch de hidratação: o carrinho vem do localStorage.
  useEffect(() => setMounted(true), []);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-sand/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="font-display text-2xl tracking-tight text-ink">
          Vero <span className="text-gold">Mercado</span>
        </Link>

        <nav className="flex items-center gap-6 font-body text-sm text-ink">
          <Link href="/" className="hover:text-forest">
            Catálogo
          </Link>

          {user?.role === "ADMIN" && (
            <Link href="/admin" className="hover:text-forest">
              Painel Admin
            </Link>
          )}

          {user && (
            <Link href="/orders" className="hover:text-forest">
              Meus Pedidos
            </Link>
          )}

          <Link href="/cart" className="relative hover:text-forest">
            Carrinho
            {mounted && count > 0 && (
              <span className="absolute -right-3 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-rust text-[11px] font-semibold text-paper">
                {count}
              </span>
            )}
          </Link>

          {user ? (
            <div className="flex items-center gap-3">
              <span className="hidden text-ink/60 sm:inline">Olá, {user.name.split(" ")[0]}</span>
              <button
                onClick={logout}
                className="focus-ring rounded-full border border-ink/20 px-3 py-1 hover:bg-ink hover:text-paper transition-colors"
              >
                Sair
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="focus-ring rounded-full bg-forest px-4 py-1.5 text-paper hover:bg-ink transition-colors"
            >
              Entrar
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
