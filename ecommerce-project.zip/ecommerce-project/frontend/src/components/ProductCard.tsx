import Image from "next/image";
import Link from "next/link";
import { Product } from "@/lib/types";

const formatBRL = (value: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value);

export default function ProductCard({ product }: { product: Product }) {
  return (
    <Link
      href={`/product/${product.id}`}
      className="group tag-card focus-ring block bg-paper shadow-sm transition-transform hover:-translate-y-0.5 hover:shadow-md"
    >
      <span className="tag-hole" aria-hidden />
      <div className="relative aspect-square w-full overflow-hidden bg-sand">
        {product.imageUrl ? (
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-ink/30">Sem imagem</div>
        )}
        {product.stock === 0 && (
          <span className="absolute right-2 top-2 rounded-full bg-rust px-2 py-0.5 text-xs text-paper">
            Esgotado
          </span>
        )}
      </div>
      <div className="space-y-1 p-4">
        <p className="font-body text-xs uppercase tracking-wide text-ink/50">
          {product.category?.name}
        </p>
        <h3 className="font-display text-lg leading-tight text-ink">{product.name}</h3>
        <p className="font-display text-xl text-gold">{formatBRL(product.price)}</p>
      </div>
    </Link>
  );
}
